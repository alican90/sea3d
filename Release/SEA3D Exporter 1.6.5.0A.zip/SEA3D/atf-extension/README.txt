NOTICE:

Tool for converting DDS files into ATF files suitable for use with the Flash Stage3D API
by Adobe

https://github.com/adobe/dds2atf